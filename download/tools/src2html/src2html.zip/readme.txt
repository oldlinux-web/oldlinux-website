see files

  info.htm
  example/example.htm

for detailed information about src2htm.

List of files
=============
info.htm                  <===== read this
infolf.htm
infosrc.htm
langkeywords.ini
otherkeywords.ini
readme.txt
src2html
src2html.ini
src2html.js  

example/example.c
example/example.htm       <===== read this
example/otherkeywords.ini
example/info.html
example/src2html.ini
example/src2html.js
example/examplesrc.htm
example/examplelf.htm

nectarKeywords/otherkeywords.ini  (Nectar API)

