                           
function q_help( zp_anchor)
 {    
   MeinFenster = window.open("help.html", "helpfile");
   MeinFenster.focus();
   MeinFenster.location.href = "help.html#"+zp_anchor;
 }
  


