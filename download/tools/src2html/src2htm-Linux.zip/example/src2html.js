                           
function q_help( zp_anchor)
 {    
   MeinFenster = window.open("info.html", "helpfile");
   MeinFenster.focus();
   MeinFenster.location.href = "info.html#"+zp_anchor;
 }
  


